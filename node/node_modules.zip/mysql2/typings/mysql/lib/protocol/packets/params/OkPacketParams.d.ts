declare interface OkPacketParams {
  affectedRows?: number;
  insertId?: number;
  serverStatus?: number;
  warningCount?: number;
  message?: string;
}

export { OkPacketParams };
