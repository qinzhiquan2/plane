/**
 * @author troyeagle
*/
/// <reference types="node" />
import AliPayForm from './form';
export declare function isDebugMode(): boolean;
/**
 * @interface AlipaySdkConfig SDK 配置
 */
export interface AlipaySdkConfig {
    /** 应用ID */
    appId: string;
    /** 应用私钥字符串。RSA签名验签工具：https://docs.open.alipay.com/291/106097）*/
    privateKey: string;
    /** 签名种类 */
    signType?: 'RSA2' | 'RSA';
    /** 支付宝公钥（需要对返回值做验签时候必填） */
    alipayPublicKey?: string;
    /** 网关 */
    gateway?: string;
    /** 网关超时时间（单位毫秒，默认 5s） */
    timeout?: number;
    /** 是否把网关返回的下划线 key 转换为驼峰写法 */
    camelcase?: boolean;
    /** 编码（只支持 utf-8） */
    charset?: 'utf-8';
    /** api版本 */
    version?: '1.0';
    /** 指定 urllib 库 */
    urllib?: any;
    /** 指定private key类型, 默认： PKCS1, PKCS8: PRIVATE KEY, PKCS1: RSA PRIVATE KEY */
    keyType?: 'PKCS1' | 'PKCS8';
    /** 应用公钥证书文件路径 */
    appCertPath?: string;
    /** 应用公钥证书文件内容 */
    appCertContent?: string | Buffer;
    /** 应用公钥证书sn */
    appCertSn?: string;
    /** 支付宝根证书文件路径 */
    alipayRootCertPath?: string;
    /** 支付宝根证书文件内容 */
    alipayRootCertContent?: string | Buffer;
    /** 支付宝根证书sn */
    alipayRootCertSn?: string;
    /** 支付宝公钥证书文件路径 */
    alipayPublicCertPath?: string;
    /** 支付宝公钥证书文件内容 */
    alipayPublicCertContent?: string | Buffer;
    /** 支付宝公钥证书sn */
    alipayCertSn?: string;
    /** AES密钥，调用AES加解密相关接口时需要 */
    encryptKey?: string;
    /** 服务器地址 */
    wsServiceUrl?: string;
}
export interface AlipaySdkCommonResult {
    /** 响应码。10000 表示成功，其余详见 https://opendocs.alipay.com/common/02km9f */
    code: string;
    /** 响应讯息。Success 表示成功。 */
    msg: string;
    /** 错误代号 */
    sub_code?: string;
    /** 错误辅助信息 */
    sub_msg?: string;
    /** trace id */
    traceId?: string;
    /** 请求返回内容，详见各业务接口 */
    [key: string]: any;
}
export interface IRequestParams {
    [key: string]: any;
    /** 业务请求参数 */
    bizContent?: Record<string, any>;
    /** 自动AES加解密 */
    needEncrypt?: boolean;
}
export interface IRequestOption {
    validateSign?: boolean;
    log?: {
        info(...args: any[]): any;
        error(...args: any[]): any;
    };
    formData?: AliPayForm;
}
/**
 * Alipay SDK for Node.JS
 */
declare class AlipaySdk {
    private sdkVersion;
    config: AlipaySdkConfig;
    /**
     * @class
     * @param {AlipaySdkConfig} config 初始化 SDK 配置
     */
    constructor(config: AlipaySdkConfig);
    private formatKey;
    private formatUrl;
    private multipartExec;
    /**
     * 生成请求字符串，用于客户端进行调用
     * @param {string} method 方法名
     * @param {IRequestParams} params 请求参数
     * @param {object} params.bizContent 业务请求参数
     * @return {string} 请求字符串
     */
    sdkExec(method: string, params: IRequestParams): string;
    /**
     * 生成网站接口请求链接或表单
     * @param {string} method 方法名
     * @param {IRequestParams} params 请求参数
     * @param {object} params.bizContent 业务请求参数
     * @param {string} params.method 后续进行请求的方法。如为 GET，即返回 http 链接；如为 POST，则生成表单 html
     * @return {string} 请求链接或表单 HTML
     */
    pageExec(method: string, params: IRequestParams & {
        method?: 'GET' | 'POST';
    }): string;
    private _pageExec;
    private notifyRSACheck;
    /**
     * @ignore
     * @param originStr 开放平台返回的原始字符串
     * @param responseKey xx_response 方法名 key
     */
    getSignStr(originStr: string, responseKey: string): string;
    exec<T = {}>(method: string, params?: IRequestParams, option?: Omit<IRequestOption, 'formData'>): Promise<AlipaySdkCommonResult & T>;
    exec(method: string, params?: IRequestParams, option?: IRequestOption): Promise<AlipaySdkCommonResult | string>;
    checkResponseSign(signStr: string, responseKey: string): boolean;
    /**
     * 通知验签
     * @param {JSON} postData 服务端的消息内容
     * @param {Boolean} raw 是否使用 raw 内容而非 decode 内容验签
     * @return { Boolean } 验签是否成功
     */
    checkNotifySign(postData: any, raw?: boolean): boolean;
}
export default AlipaySdk;
