
3.6.2 / 2024-06-01
==================

**fixes**
  * [[`e1d448e`](http://github.com/alipay/alipay-sdk-nodejs-all/commit/e1d448ea3a5e6de9768b345ab4e234b6f684ad68)] - fix: traceId should only appear in debug mode (#113) (Genefy <<troyeagledzh@gmail.com>>)

**others**
  * [[`5a80fcc`](http://github.com/alipay/alipay-sdk-nodejs-all/commit/5a80fcc3ba7403af5fddf2afd46416631dd16298)] - chore: remove auto release on 3.x (fengmk2 <<suqian.yf@antgroup.com>>)
  * [[`c7f236b`](http://github.com/alipay/alipay-sdk-nodejs-all/commit/c7f236b0741940eed019887703ee7f885598e98e)] - chore: start 3.x branch LTS (fengmk2 <<fengmk2@gmail.com>>)
