
# Audit

`npm install audit`

Audit is a benchmarking tool for asynchronous or synchronous functions. It generates the following statistics:

* elapsed time
* iterations
* operations per second
* mean
* median
* mode
* max
* min


## Basic usage

```js
var Audit = require('audit')
var audit = new Audit({
    iterations:100
})

audit.on('complete', function(stats) {
    console.log(stats)
})

audit.on('auditing', function(name) {
    console.log('Auditing', name, '...')
})

audit.on('auditcomplete', function(stats) {
    console.log('Completed', stats.name)
})

audit.async(function(next) {
    return next()
})

audit.sync(function() {
    return 1
})

audit.run()
```

## Chaining

```js
var Audit = require('audit')
var audit = new Audit()

audit.on('complete', console.log)

audit
.async('mytestname', function(next) {
    return next()
})
.async('mytestname2', function(next) {
    return next()
})
.async('mytestname3', function(next) {
    return next()
})
.run()

```

## Stats

The stats object contains the following properties:

* `name`
* `elapsed`
* `iterations`
* `opsPerSecond`
* `mode`
* `median`
* `mean`
* `max`
* `min`

Sample output:

```
Benching musicmetadata...
musicmetadata 23.12673450508788
Benching child-ffmpeg...
child-ffmpeg 7.58150113722517
{
    "musicmetadata": {
        "name": "musicmetadata",
        "elapsed": "4324ms",
        "iterations": 100,
        "opsPerSecond": 23.12673450508788,
        "mode": [ "19ms", "1occ" ],
        "median": "45ms",
        "mean": "43.676767676767675ms",
        "max": [ "61ms", "7ind" ],
        "min": [ "19ms", "0ind" ]
},
    "child-ffmpeg": {
        "name": "child-ffmpeg",
        "elapsed": "13190ms",
        "iterations": 100,
        "opsPerSecond": 7.58150113722517,
        "mode": [ "128ms", "1occ" ],
        "median": "131ms",
        "mean": "133.23232323232324ms",
        "max": [ "221ms", "0ind" ],
        "min": [ "128ms", "19ind" ]
    }
}

```

## Options

Pass options to the audit constructor function in an object. Options and their default values follow.

* `iterations` **Number** *1000*

Number of times to execute the provided functions

* `pause` **Number** *100*

Number of milliseconds to pause between audits.
