var myMoule = require('./singleobject').Hello("dsf");

/* myMoule.setName("lihao__");
myMoule.sayHello(); */