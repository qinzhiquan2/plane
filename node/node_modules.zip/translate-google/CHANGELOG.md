# Change Log

## 1.4.3 [2020-08-10]
### Fixed
- Clone a new input so that it will not affect the original variable

## 1.4.2 [2020-07-28]
### Changed
- Changed url params processing method

## 1.4.1 [2020-07-27]
### Changed
- Change the submission module of post

## 1.4.0 [2020-07-16]
### Fixed
- Fixed Lots of translations bug

## 1.3.4 [2019-01-15]
### Added
- Added object translation exclusions
- Remove the duplicate part of the translation
### Fixed
- Fixed Object bug

## 1.3.4 [2019-01-12]
### Fixed
- Translate a large number of characters using POST method

## 1.3.3 [2019-01-10]
### Added
- Object mode translation: Excluding non-words that do not participate in translation

## 1.3.2 [2019-01-10]
### Added
- Object mode translation: Exclude numbers, URLs, keywords in translate

## 1.3.1 [2019-01-09]
### Fixed
- Fixed some bug

## 1.3.0 [2019-01-09]
### Changed
- Perfect support object
